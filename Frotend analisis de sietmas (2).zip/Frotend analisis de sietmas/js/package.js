  // js de index
  const stats = document.querySelectorAll('.stat-number');
        
  stats.forEach(stat => {
      const target = parseInt(stat.getAttribute('data-target'));
        const increment = target / 100;
      
        function updateCount() {
        const count = parseInt(stat.innerText);
            if(count < target) {
                stat.innerText = Math.ceil(count + increment);
                setTimeout(updateCount, 20);
            } else {
                stat.innerText = target;
          }
      }
      
        updateCount();
  });

  // Funcionalidad del buscador
  const searchToggle = document.getElementById('search-toggle');
  const searchBox = document.getElementById('search-box');

  searchToggle.addEventListener('click', (e) => {
      e.preventDefault();
      searchBox.classList.toggle('active');
  });

  // Cerrar búsqueda al hacer clic fuera
  document.addEventListener('click', (e) => {
      if (!e.target.closest('.search-container')) {
          searchBox.classList.remove('active');
      }
  });

  // Funcionalidad del slider
  let currentSlideIndex = 4;

  function currentSlide(n) {
      showSlide(currentSlideIndex = n);
  }

  function showSlide(n) {
      const dots = document.getElementsByClassName("dot");
      for (let i = 0; i < dots.length; i++) {
          dots[i].className = dots[i].className.replace(" active", "");
      }
      dots[currentSlideIndex-1].className += " active";
  }

  // Carrito de compras
  let cartCount = 0;
  const cartCountElement = document.querySelector('.cart-count');
  
  function updateCart() {
      cartCountElement.textContent = cartCount;
  }

  // Ejemplo de añadir al carrito (puedes conectar esto a botones de productos)
  document.querySelector('.cart-icon').addEventListener('click', (e) => {
      e.preventDefault();
      cartCount++;
      updateCart();
  });

  // js de ordenes


  document.addEventListener('DOMContentLoaded', function() {
    // Funcionalidad de búsqueda
    const searchIcon = document.querySelector('.search-icon3');
    const searchInput = document.querySelector('.search-input3');

    if (searchIcon && searchInput) {
        searchIcon.addEventListener('click', () => {
            searchInput.classList.toggle('active');
            if (searchInput.classList.contains('active')) {
                searchInput.focus();
            }
        });

        searchInput.addEventListener('input', (e) => {
            const searchTerm = e.target.value.toLowerCase();
            const orders = document.querySelectorAll('.order');

            orders.forEach(order => {
                const orderText = order.textContent.toLowerCase();
                order.style.display = orderText.includes(searchTerm) ? 'flex' : 'none';
            });
        });
    }

    // Funcionalidad de pestañas
    const tabs = document.querySelectorAll('.tab');
    const orders = document.querySelectorAll('.order');

    tabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            e.preventDefault();
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            const status = tab.dataset.tab;

            orders.forEach(order => {
                order.style.display = (status === 'all' || order.dataset.status === status) ? 'flex' : 'none';
            });
        });
    });

    // Funcionalidad del modal
    const modal = document.getElementById('newOrderModal');
    const createOrderBtn = document.querySelector('.create-order');
    const closeModal = document.querySelector('.close-modal');
    const orderForm = document.getElementById('newOrderForm');
    const orderNumberError = document.getElementById('orderNumberError');

    if (createOrderBtn && modal) {
        createOrderBtn.addEventListener('click', () => {
            modal.classList.add('active');
        });
    }

    if (closeModal && modal) {
        closeModal.addEventListener('click', () => {
            modal.classList.remove('active');
            orderNumberError.style.display = 'none';
            orderForm.reset();
        });
    }

    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('active');
            orderNumberError.style.display = 'none';
            orderForm.reset();
        }
    });

    if (orderForm) {
        orderForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const orderNumber = document.getElementById('orderNumber').value;
            const items = document.getElementById('items').value;
            const amount = document.getElementById('amount').value;

            // Verificar si el número de orden ya existe
            const existingOrders = document.querySelectorAll('.order h3');
            const orderExists = Array.from(existingOrders).some(order => 
                order.textContent === `Orden #${orderNumber}`
            );

            if (orderExists) {
                orderNumberError.style.display = 'block';
                return;
            }

            const newOrder = document.createElement('div');
            newOrder.className = 'order';
            newOrder.dataset.status = 'open';
            newOrder.innerHTML = `
                <div class="order-details">
                    <h3>Orden #${orderNumber}</h3>
                    <div class="order-items">Por ${items} artículos</div>
                </div>
                <div class="order-amount">$${amount}</div>
            `;

            document.querySelector('.orders').appendChild(newOrder);
            modal.classList.remove('active');
            orderNumberError.style.display = 'none';
            orderForm.reset();
        });
    }

    // Funcionalidad al hacer clic en las órdenes
    const ordersContainer = document.querySelector('.orders');
    if (ordersContainer) {
        ordersContainer.addEventListener('click', (e) => {
            const order = e.target.closest('.order');
            if (order) {
                order.dataset.status = order.dataset.status === 'open' ? 'closed' : 'open';
                // Actualizar la vista según la pestaña actual
                document.querySelector('.tab.active').click();
            }
        });
    }
});