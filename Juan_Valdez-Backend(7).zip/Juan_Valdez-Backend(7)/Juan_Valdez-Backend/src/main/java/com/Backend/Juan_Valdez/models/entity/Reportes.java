package com.Backend.Juan_Valdez.models.entity;

import jakarta.persistence.*;

import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name="reportes")
public class Reportes implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 100)
    private String fecha;
    private double total_ventas;
    private int cantidad_productos_vendidos;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public double getTotal_ventas() {
        return total_ventas;
    }

    public void setTotal_ventas(double total_ventas) {
        this.total_ventas = total_ventas;
    }

    public int getCantidad_productos_vendidos() {
        return cantidad_productos_vendidos;
    }

    public void setCantidad_productos_vendidos(int cantidad_productos_vendidos) {
        this.cantidad_productos_vendidos = cantidad_productos_vendidos;
    }

    private static final long serialVersionUID=1L;
}
