package com.Backend.Juan_Valdez.controllers;

import com.Backend.Juan_Valdez.models.entity.Ordenes;
import com.Backend.Juan_Valdez.models.entity.Reportes;
import com.Backend.Juan_Valdez.models.service.IReportesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/reportes_ventas")
public class ReportesRestController {

    @Autowired
    private IReportesService ReportesService;

    @GetMapping()
    public List<Reportes> index() {
        return ReportesService.findAll();
    }

   /* @PostMapping("")
    public Cliente save(@RequestBody Cliente cliente){
        return service.save(cliente); }*/

    @GetMapping("/reportes/{id}")
    public Reportes show(@PathVariable Long id){
        return ReportesService.findById(id);
    }

    @PostMapping("/reportes")
    @ResponseStatus(HttpStatus.CREATED)
    public Reportes create(@RequestBody Reportes reportes){
        return ReportesService.save(reportes);
    }

    @PutMapping("/reportes/{id}")
    @ResponseStatus(HttpStatus.CREATED)
    public Reportes update (@RequestBody Reportes reportes, @PathVariable Long id){
        Reportes reportesActual = ReportesService.findById(id);

        reportesActual.setFecha(reportes.getFecha());
        reportesActual.setTotal_ventas(reportes.getTotal_ventas());
        reportesActual.setCantidad_productos_vendidos(reportes.getCantidad_productos_vendidos());

        return ReportesService.save(reportesActual);

    }

    @DeleteMapping("/reportes/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id){
        ReportesService.delete(id);
    }



}

