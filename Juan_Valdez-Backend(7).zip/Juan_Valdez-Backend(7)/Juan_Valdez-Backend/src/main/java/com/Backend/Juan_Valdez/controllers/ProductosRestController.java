package com.Backend.Juan_Valdez.controllers;

import com.Backend.Juan_Valdez.models.entity.Ordenes;
import com.Backend.Juan_Valdez.models.entity.Productos;
import com.Backend.Juan_Valdez.models.service.IProductosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/productos")
@CrossOrigin("*")
public class ProductosRestController {

    @Autowired
    private IProductosService ProductosService;

    @GetMapping("")
    public List<Productos> index() {
        return ProductosService.findAll();
    }

    @GetMapping("/productos/{id}")
    public Productos show(@PathVariable Long id){return ProductosService.findById(id);}

    /*@PostMapping("/productos")
    @ResponseStatus(HttpStatus.CREATED)
    public Productos create(@RequestBody Productos productos){
        Productos Productos = new Productos();
        return ProductosService.save(Productos);
    }*/

    // Crear una nueva orden
    @PostMapping("/producto")
    @ResponseStatus(HttpStatus.CREATED)
    public Productos create(@RequestBody Productos productos) {
        return ProductosService.save(productos);
    }

    @PutMapping("/productos/{id}")
    @ResponseStatus(HttpStatus.CREATED)
    public Productos update (@RequestBody Productos Productos, @PathVariable Long id){
        Productos ProductosActual = ProductosService.findById(id);

        ProductosActual.setNombre(Productos.getNombre());
        ProductosActual.setPrecio(Productos.getPrecio());
        ProductosActual.setCantidad_en_stock(Productos.getCantidad_en_stock());
        ProductosActual.setCategoria(Productos.getCategoria());
        ProductosActual.setDescripcion(Productos.getDescripcion());

        return ProductosService.save(ProductosActual);
    }

    @DeleteMapping("/productos/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id){
        ProductosService.delete(id);
    }



   /* @GetMapping("/productos/{id}")
    public Juan_Valdez show(@PathVariable Long id){return JuanValdezService.findById(id);}

    @PostMapping("/productos")
    @ResponseStatus(HttpStatus.CREATED)
    public Juan_Valdez create(@RequestBody Juan_Valdez juanValdez){
        return JuanValdezService.save(juanValdez);
    }

    @PutMapping("/productos/{id}")
    @ResponseStatus(HttpStatus.CREATED)
    public Juan_Valdez update (@RequestBody Juan_Valdez juanValdez, @PathVariable Long id){
        Juan_Valdez juanValdezActual = JuanValdezService.findById(id);

        juanValdezActual.setNomTarea(juanValdez.getNomTarea());
        juanValdezActual.setDescripcion(juanValdez.getDescripcion());
        juanValdezActual.setEmail(juanValdez.getEmail());
        juanValdezActual.setResponsable(juanValdez.getResponsable());

        return JuanValdezService.save(juanValdezActual);
    }

    @DeleteMapping("/productos/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id){
        JuanValdezService.delete(id);
    }*/
}
