package com.Backend.Juan_Valdez.models.service;

import com.Backend.Juan_Valdez.models.dao.IReportesDao;
import com.Backend.Juan_Valdez.models.entity.Reportes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class ReportesServiceImpl implements IReportesService {

    @Autowired
    private IReportesDao ReportesDao;

    @Override
    @Transactional(readOnly = true)
    public List<Reportes> findAll() {
        return (List<Reportes>) ReportesDao.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Reportes findById(Long id) {
        return ReportesDao.findById(id).orElse(null);
    }

    @Override
    @Transactional
    public Reportes save(Reportes reportes) {
        return ReportesDao.save(reportes);
    }

    @Override
    @Transactional
    public void delete(Long id) {
        ReportesDao.deleteById(id);
    }
}
