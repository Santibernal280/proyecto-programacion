package com.Backend.Juan_Valdez.models.service;

import com.Backend.Juan_Valdez.models.entity.Productos;
import com.Backend.Juan_Valdez.models.entity.Reportes;

import java.util.List;
import java.util.Optional;

public interface IReportesService {
    public List<Reportes> findAll();

    public Reportes findById(Long id);

    public Reportes save (Reportes reportes);

    public void delete(Long id);
}



