package com.Backend.Juan_Valdez.models.dao;

import com.Backend.Juan_Valdez.models.entity.Productos;
import org.springframework.data.repository.CrudRepository;

public interface IProductosDao extends CrudRepository<Productos, Long> {
}