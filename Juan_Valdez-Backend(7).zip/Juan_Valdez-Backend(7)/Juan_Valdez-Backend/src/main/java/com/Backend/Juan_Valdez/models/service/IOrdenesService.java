package com.Backend.Juan_Valdez.models.service;

import com.Backend.Juan_Valdez.models.entity.Ordenes;

import java.util.List;
import java.util.Optional;

public interface IOrdenesService {
    public List<Ordenes> findAll();

    // Método para obtener una orden por su ID
    public Ordenes findById(Long id);

    // Método para guardar o actualizar una orden
    public Ordenes save(Ordenes ordenes);

    // Método para eliminar una orden por su ID
    public void delete(Long id);



}



