package com.Backend.Juan_Valdez.models.service;

import com.Backend.Juan_Valdez.models.entity.Ordenes;
import com.Backend.Juan_Valdez.models.entity.Productos;
import com.Backend.Juan_Valdez.models.entity.Reportes;

import java.util.List;

public interface IProductosService {
    public List<Productos> findAll();

    public Productos findById(Long id);

    public Productos save (Productos productos);

    public void delete(Long id);
}