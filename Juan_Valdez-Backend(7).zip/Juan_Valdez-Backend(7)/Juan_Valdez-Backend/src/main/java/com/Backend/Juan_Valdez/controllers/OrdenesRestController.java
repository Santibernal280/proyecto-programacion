package com.Backend.Juan_Valdez.controllers;

import com.Backend.Juan_Valdez.models.entity.Ordenes;
import com.Backend.Juan_Valdez.models.service.IOrdenesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/Ordenes")
public class OrdenesRestController {

    @Autowired
    private IOrdenesService OrdenesService;

    @GetMapping()
    public List<Ordenes> index() {
        return OrdenesService.findAll();
    }

    // Obtener una orden específica por su ID
    @GetMapping("/ordenes/{id}")
    public Ordenes show(@PathVariable Long id) {
        return OrdenesService.findById(id);
    }

    // Crear una nueva orden
    @PostMapping("/ordenes")
    @ResponseStatus(HttpStatus.CREATED)
    public Ordenes create(@RequestBody Ordenes ordenes) {
        return OrdenesService.save(ordenes);
    }

    // Actualizar una orden existente por su ID
    @PutMapping("/ordenes/{id}")
    @ResponseStatus(HttpStatus.CREATED)
    public Ordenes update(@RequestBody Ordenes ordenes, @PathVariable Long id) {
        Ordenes OrdenesActual = OrdenesService.findById(id);

            OrdenesActual.setFecha(ordenes.getFecha());
            OrdenesActual.setCliente(ordenes.getCliente());
            OrdenesActual.setTotal(ordenes.getTotal());
            OrdenesActual.setEstado(ordenes.getEstado());

            return OrdenesService.save(OrdenesActual);
        }


    // Eliminar una orden por su ID
    @DeleteMapping("/ordenes/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        OrdenesService.delete(id);}

}







