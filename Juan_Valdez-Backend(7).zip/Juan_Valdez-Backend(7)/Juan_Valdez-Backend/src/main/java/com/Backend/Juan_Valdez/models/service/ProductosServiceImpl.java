package com.Backend.Juan_Valdez.models.service;

import com.Backend.Juan_Valdez.models.dao.IProductosDao;
import com.Backend.Juan_Valdez.models.dao.IReportesDao;
import com.Backend.Juan_Valdez.models.entity.Ordenes;
import com.Backend.Juan_Valdez.models.entity.Productos;
import com.Backend.Juan_Valdez.models.entity.Reportes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ProductosServiceImpl implements IProductosService {
    @Autowired
    private IProductosDao ProductosDao;
    @Override
    @Transactional(readOnly = true)
    public List<Productos> findAll() {
        return (List<Productos>) ProductosDao.findAll();
    }


    @Override
    @Transactional(readOnly = true)
    public Productos findById(Long id) {
        return ProductosDao.findById(id).orElse(null);
    }

    @Override
    @Transactional
    public Productos save(Productos productos) {
        return ProductosDao.save(productos);
    }

    @Override
    @Transactional
    public void delete(Long id) {
        ProductosDao.deleteById(id);
    }


}