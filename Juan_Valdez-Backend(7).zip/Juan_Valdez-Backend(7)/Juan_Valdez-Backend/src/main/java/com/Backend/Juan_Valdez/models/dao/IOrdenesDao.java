package com.Backend.Juan_Valdez.models.dao;

import com.Backend.Juan_Valdez.models.entity.Ordenes;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.TemporalType;
import org.springframework.data.annotation.Id;
import org.springframework.data.jpa.repository.Temporal;
import org.springframework.data.repository.CrudRepository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface IOrdenesDao extends CrudRepository<Ordenes,Long>{
    public List<Ordenes> findAll();
   /* Optional<Ordenes> findById(Long  id);
    Ordenes save(Ordenes orden);
    Boolean delete(Long id);
    List<Ordenes> findByEstado(String estado);

    //void deleteById(Integer id);*/
}



