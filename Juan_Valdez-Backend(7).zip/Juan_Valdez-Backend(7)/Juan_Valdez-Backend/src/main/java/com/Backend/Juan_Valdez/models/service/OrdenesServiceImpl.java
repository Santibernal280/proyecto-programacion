package com.Backend.Juan_Valdez.models.service;

import com.Backend.Juan_Valdez.models.dao.IOrdenesDao;
import com.Backend.Juan_Valdez.models.entity.Ordenes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class OrdenesServiceImpl implements IOrdenesService {
    @Autowired
    private IOrdenesDao OrdenesDao;
    @Override
    @Transactional(readOnly = true)
    public List<Ordenes> findAll() {
        return (List<Ordenes>) OrdenesDao.findAll();
    }

    // Busca una orden por su ID
    @Override
    @Transactional(readOnly = true)
    public Ordenes findById(Long id) {
        return OrdenesDao.findById(id).orElse(null);
    }

    // Guarda o actualiza una orden en la base de datos
    @Override
    @Transactional
    public Ordenes save(Ordenes ordenes) {
        return OrdenesDao.save(ordenes);
    }

    // Elimina una orden por su ID
    @Override
    @Transactional
    public void delete(Long id) {
        OrdenesDao.deleteById(id);
}




}



