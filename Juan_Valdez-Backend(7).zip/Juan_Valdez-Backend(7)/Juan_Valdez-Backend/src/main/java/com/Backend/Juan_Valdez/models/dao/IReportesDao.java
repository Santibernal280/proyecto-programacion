package com.Backend.Juan_Valdez.models.dao;


import com.Backend.Juan_Valdez.models.entity.Reportes;
import org.springframework.data.repository.CrudRepository;

public interface IReportesDao extends CrudRepository<Reportes, Long> {

}




